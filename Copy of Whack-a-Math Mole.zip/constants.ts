
export const GAME_DURATION = 60; // in seconds
